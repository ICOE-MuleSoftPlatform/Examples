All the CI/CD , LCM and deployment details should be mentioned in 
deployment_readme.txt